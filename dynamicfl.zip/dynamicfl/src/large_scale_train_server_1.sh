#!/bin/bash
#!/bin/bash
CUDA_VISIBLE_DEVICES="0" python train_classifier_fl.py --init_seed 0 --world_size 1 --num_experiments 1 --resume_mode 0 --log_interval 0.25 --device cuda --control_name CIFAR10_resnet9_100_iid_dynamicfl_fix_0.2-0.8_2-1_250&
CUDA_VISIBLE_DEVICES="1" python train_classifier_fl.py --init_seed 0 --world_size 1 --num_experiments 1 --resume_mode 0 --log_interval 0.25 --device cuda --control_name CIFAR10_resnet9_100_iid_dynamicfl_fix_0.5-0.5_2-1_250&
CUDA_VISIBLE_DEVICES="2" python train_classifier_fl.py --init_seed 0 --world_size 1 --num_experiments 1 --resume_mode 0 --log_interval 0.25 --device cuda --control_name CIFAR10_resnet9_100_iid_dynamicfl_fix_0.8-0.2_2-1_250&
CUDA_VISIBLE_DEVICES="3" python train_classifier_fl.py --init_seed 0 --world_size 1 --num_experiments 1 --resume_mode 0 --log_interval 0.25 --device cuda --control_name CIFAR10_resnet9_100_non-iid-d-0.1_dynamicfl_fix_0.2-0.8_2-1_250&
CUDA_VISIBLE_DEVICES="0" python train_classifier_fl.py --init_seed 0 --world_size 1 --num_experiments 1 --resume_mode 0 --log_interval 0.25 --device cuda --control_name CIFAR10_resnet9_100_non-iid-d-0.1_dynamicfl_fix_0.5-0.5_2-1_250&
CUDA_VISIBLE_DEVICES="1" python train_classifier_fl.py --init_seed 0 --world_size 1 --num_experiments 1 --resume_mode 0 --log_interval 0.25 --device cuda --control_name CIFAR10_resnet9_100_non-iid-d-0.1_dynamicfl_fix_0.8-0.2_2-1_250&
CUDA_VISIBLE_DEVICES="2" python train_classifier_fl.py --init_seed 0 --world_size 1 --num_experiments 1 --resume_mode 0 --log_interval 0.25 --device cuda --control_name CIFAR10_resnet9_100_non-iid-d-1_dynamicfl_fix_0.2-0.8_2-1_250&
CUDA_VISIBLE_DEVICES="3" python train_classifier_fl.py --init_seed 0 --world_size 1 --num_experiments 1 --resume_mode 0 --log_interval 0.25 --device cuda --control_name CIFAR10_resnet9_100_non-iid-d-1_dynamicfl_fix_0.5-0.5_2-1_250
wait
