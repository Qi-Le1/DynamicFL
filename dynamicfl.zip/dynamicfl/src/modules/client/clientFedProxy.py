from __future__ import annotations

import copy
import datetime
import numpy as np
import sys
import time
import torch
import torch.nn.functional as F
import models
from itertools import compress
from config import cfg

# from torchstat import stat

from utils.api import (
    to_device,  
    collate
)

from _typing import (
    ClientType,
    ModelType,
    DatasetType,
    MetricType,
    LoggerType
)

from models.api import (
    create_model
)

from optimizer.api import create_optimizer

from data import make_data_loader

from .clientBase import ClientBase


class ClientFedProxy(ClientBase):

    def __init__(
        self, 
        client_id: int, 
        model: ModelType, 
        data_split: list[int],
    ) -> None:

        super().__init__()
        self.client_id = client_id
        self.data_split = data_split
        self.model_state_dict = {k: v.cpu() for k, v in model.state_dict().items()}
        self.model_state_dict_for_proxy = {k: v.cpu() for k, v in model.state_dict().items()}
        optimizer = create_optimizer(model, 'client')
        self.optimizer_state_dict = optimizer.state_dict()
        self.active = False

    @classmethod
    def create_clients(
        cls,
        model: ModelType, 
        data_split: dict[str, dict[int, list[int]]],
    ) -> dict[int, ClientType]:

        client_ids = torch.arange(cfg['num_clients'])
        clients = [None for _ in range(cfg['num_clients'])]
        for m in range(len(clients)):
            clients[m] = ClientFedProxy(
                client_id=client_ids[m], 
                model=model, 
                data_split={
                    'train': data_split['train'][m], 
                    'test': data_split['test'][m]
                }
            )
        return clients

    def add_proximal_term(
        self,
        client_proxy_model,
        server_model,
        output
    ) -> None:

        proximal_term = 0.0
        for w, w_t in zip(client_proxy_model.parameters(), server_model.parameters()):
            proximal_term += (w - w_t).norm(2)
        output['loss'] += proximal_term
        return
        
    def train(
        self, 
        dataset: DatasetType, 
        lr: int, 
        metric: MetricType, 
        logger: LoggerType,
        grad_updates_num: int,
    ) -> None:
        
        model = create_model()
        model.load_state_dict(self.model_state_dict, strict=False)

        client_proxy_model = create_model()
        client_proxy_model.load_state_dict(self.model_state_dict_for_proxy, strict=False)
        self.optimizer_state_dict['param_groups'][0]['lr'] = lr
        optimizer = create_optimizer(model, 'client')
        optimizer.load_state_dict(self.optimizer_state_dict)
        model.train(True)

        cur_grad_updates_num = 0
        while cur_grad_updates_num < grad_updates_num:
            # Regenerate data loader if number of data_loader batches < grad_interval
            # number of data_loader batches = num of data points / batch_size
            data_loader = make_data_loader(
                dataset={'train': dataset}, 
                tag='client'
            )['train'] 

            for i, input in enumerate(data_loader):
                cur_grad_updates_num += 1                      
                if cur_grad_updates_num == grad_updates_num + 1:
                    break

                input = collate(input)
                input_size = input['data'].size(0)
                input = to_device(input, cfg['device'])
                optimizer.zero_grad()
                output = model(input)
                # add proxy term to output['loss']
                self.add_proximal_term(
                    client_proxy_model=client_proxy_model, 
                    server_model=model,
                    output=output
                )
                output['loss'].backward()
 
                torch.nn.utils.clip_grad_norm_(model.parameters(), 1)
                optimizer.step()
                evaluation = metric.evaluate(
                    metric.metric_name['train'], 
                    input, 
                    output
                )
                logger.append(
                    evaluation, 
                    'train', 
                    n=input_size
                )
        self.optimizer_state_dict = optimizer.state_dict()
        self.model_state_dict = {k: v.cpu() for k, v in model.state_dict().items()}
        self.model_state_dict_for_proxy = {k: v.cpu() for k, v in model.state_dict().items()}
        return
